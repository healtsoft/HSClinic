

<?php $__env->startSection('content'); ?>
    <div class="content fondob">
        <div class="pa fondob">
            <div class="col-md-auto">
                <table class="table">
                    <thead class="">
                        <tr>
                            <th class="centext" scole="col">Servicios</th>
                            <th class="centext" scole="col">Costo</th>
                            <th class="centext" scole="col">Opciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="centext">
                                <td class="centext" scole="col"><?php echo e($servicio->servicio); ?></td>
                                <td class="centext" scole="col">$<?php echo e($servicio->costo); ?></td>
                                <td>
                                    <a href="#" data-toggle="modal" data-target="#editUs<?php echo e($servicio->id); ?>" class="btn btn-dark d-block w-100 mb-2">Editar</a>
                                    <div class="modal fade" id="editUs<?php echo e($servicio->id); ?>">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4>Editar datos del Servicio</h4>
                                                    <button type="button" class="close" data-dismiss="modal">
                                                        <span>&times;</span>
                                                    </button>
                                                </div>
                                                <form method="POST" action="/servicio/update/<?php echo e($servicio->id); ?>">
                                                    <div class="modal-body">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="form-group">
                                                            <label for="servicio">Servicio</label>
                                                            <input type="text"
                                                                name="servicio"
                                                                class="form-control"
                                                                id="servicio"
                                                                placeholder="Servicio"
                                                                required
                                                                value="<?php echo e($servicio->servicio); ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="descripcion">Descripcion</label>
                                                            <input type="text"
                                                                name="descripcion"
                                                                class="form-control"
                                                                id="descripcion"
                                                                placeholder="Descripcion"
                                                                required
                                                                value="<?php echo e($servicio->descripcion); ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="costo">Costo</label>
                                                            <input type="text"
                                                                name="costo"
                                                                class="form-control"
                                                                id="costo"
                                                                placeholder="Costo"
                                                                required
                                                                value="<?php echo e($servicio->costo); ?>">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <input type="submit" class="btn btn-primary" value="Actualizar">
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <eliminar-servicio
                                        servicio-id=<?php echo e($servicio->id); ?>

                                    ></eliminar-servicio>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="modal fade" id="cservicio">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4>Nuevo Servicio</h4>
                    <button type="button" class="close" data-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <form method="POST" action="/admin/servicio" enctype="multipart/form-data">
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="text" name="servicio" class="form-control" id="servicio"
                                    placeholder="Servicio" required value=<?php echo e(old('servicio')); ?>>
                        </div>
                        <div class="form-group">
                            <textarea type="text" name="descripcion" class="form-control" id="descripcion"
                                placeholder="Descripcion del Servicio" required value=<?php echo e(old('descripcion')); ?> cols="30" rows="3">
                            </textarea>
                        </div>
                        <div class="form-group">
                            <input type="text" name="costo" class="form-control" id="costo"
                                    placeholder="Costo" required value=<?php echo e(old('costo')); ?>>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" class="btn btn-primary" value="Guardar">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php echo $__env->make('paciente.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Documents\GitHub\HSClinic\resources\views/admin/index.blade.php ENDPATH**/ ?>