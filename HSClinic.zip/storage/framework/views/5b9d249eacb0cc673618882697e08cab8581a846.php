

<?php $__env->startSection('hero'); ?>

    <div class="hero-categorias">
        <form class="container h-100" action=<?php echo e(route('buscar.show')); ?>>
            <div class="row h-100 align-items-center">
                <div class="col-md-4 texto-buscar">
                    <p class="display-4">Buscar pacientes por Nombre</p>

                    <input type="search" name="buscar" class="form-control" placeholder="Buscar Paciente" />
                </div>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-md-auto">
        <table class="table">
            <thead class="">
                <tr>
                    <th class="centext" scole="col">Nombre</th>
                    <th class="centext" scole="col">Opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="centext">
                        <td class="centext" scole="col"><?php echo e($paciente->nombre); ?></td>
                        <td>
                            <a href="/paciente/<?php echo e($paciente->id); ?>" class="btn btn-success">Ver</a>
                            <a href="#" data-toggle="modal" data-target="#editPx<?php echo e($paciente->id); ?>" class="btn btn-dark">Editar</a>
                            <div class="modal fade" id="editPx<?php echo e($paciente->id); ?>">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4>Editar datos del Paciente</h4>
                                            <button type="button" class="close" data-dismiss="modal">
                                                <span>&times;</span>
                                            </button>
                                        </div>
                                        <form method="POST" action="/paciente/update/<?php echo e($paciente->id); ?>">
                                            <div class="modal-body">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group">
                                                    <label for="titulo">Nombre</label>
                                                    <input type="text"
                                                        name="nombre"
                                                        class="form-control"
                                                        id="nombre"
                                                        placeholder="Nombre"
                                                        required
                                                        value="<?php echo e($paciente->nombre); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label for="fecha_nacimiento">Fecha de Nacimiento</label>
                                                    <input type="date"
                                                        name="fecha_nacimiento"
                                                        class="form-control"
                                                        id="fecha_nacimiento"
                                                        placeholder="Fecha de Nacimiento"
                                                        required
                                                        value="<?php echo e($paciente->fechaNacimiento); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label for="correo">Correo</label>
                                                    <input type="text"
                                                        name="correo"
                                                        class="form-control"
                                                        id="correo"
                                                        placeholder="Correo"
                                                        required
                                                        value="<?php echo e($paciente->correo); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label for="procedencia">Procedencia</label>
                                                    <input type="text"
                                                        name="procedencia"
                                                        class="form-control"
                                                        id="procedencia"
                                                        placeholder="Procedencia"
                                                        required
                                                        value="<?php echo e($paciente->procedencia); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label for="telefono">Telefono</label>
                                                    <input type="text"
                                                        name="telefono"
                                                        class="form-control"
                                                        id="telefono"
                                                        placeholder="Telefono"
                                                        required
                                                        value="<?php echo e($paciente->telefono); ?>">
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <input type="submit" class="btn btn-primary" value="Guardar">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <eliminar-paciente
                                servicio-id=<?php echo e($paciente->id); ?>

                            ></eliminar-paciente>
                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>
    <div class="d-flex justify-content-center mt-5">
        <?php echo e($pacientes->links()); ?>

    </div>
    <?php echo $__env->make('paciente.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pxin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Documents\GitHub\HSClinic\resources\views/paciente/index.blade.php ENDPATH**/ ?>