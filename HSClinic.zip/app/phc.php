<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class phc extends Model
{
    //
}
