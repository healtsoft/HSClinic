<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HCPX extends Model
{
    //
}
